package com.crossover.techtrial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrossSolarApplication {

  public static void main(String[] args) {
    SpringApplication.run(CrossSolarApplication.class, args);
  }

}
